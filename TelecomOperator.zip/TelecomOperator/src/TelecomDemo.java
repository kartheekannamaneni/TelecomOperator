import java.util.ArrayList;
import java.util.Scanner;

public class TelecomDemo {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Telecom t = new Telecom("xyz","399","1.5GB","unlimited","100perday","None","None","None","None");
		Telecom t1 = new Telecom("abc","499","2GB","unlimited","150perday","None","None","None","None");
		Telecom t2 = new Telecom("efg","599","2.5GB","unlimited","200perday","None","None","None","None");
		ArrayList<Telecom> arraylist = new ArrayList<Telecom>();
		arraylist.add(t);
		arraylist.add(t1);
		arraylist.add(t2);
		System.out.println(arraylist);
		Scanner sc = new Scanner(System.in);
		String plan = sc.nextLine();
		System.out.println(plan);
	}
}
