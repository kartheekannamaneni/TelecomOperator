public class Telecom {
	private String planName;
	private String monthlyRental;
	private String freeInternet;
	private String freeCalls;
	private String freeSms;
	private String callCharges;
	private String smsCharges;
	private String dataCharges;
	private String roamingCharges;
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getMonthlyRental() {
		return monthlyRental;
	}
	public void setMonthlyRental(String monthlyRental) {
		this.monthlyRental = monthlyRental;
	}
	public String getFreeInternet() {
		return freeInternet;
	}
	public void setFreeInternet(String freeInternet) {
		this.freeInternet = freeInternet;
	}
	public String getFreeCalls() {
		return freeCalls;
	}
	public void setFreeCalls(String freeCalls) {
		this.freeCalls = freeCalls;
	}
	public String getFreeSms() {
		return freeSms;
	}
	public void setFreeSms(String freeSms) {
		this.freeSms = freeSms;
	}
	public String getCallCharges() {
		return callCharges;
	}
	public void setCallCharges(String callCharges) {
		this.callCharges = callCharges;
	}
	public String getSmsCharges() {
		return smsCharges;
	}
	public void setSmsCharges(String smsCharges) {
		this.smsCharges = smsCharges;
	}
	public String getDataCharges() {
		return dataCharges;
	}
	public void setDataCharges(String dataCharges) {
		this.dataCharges = dataCharges;
	}
	public String getRoamingCharges() {
		return roamingCharges;
	}
	public void setRoamingCharges(String roamingCharges) {
		this.roamingCharges = roamingCharges;
	}
	public Telecom(String planName, String monthlyRental, String freeInternet, String freeCalls, String freeSms,
			String callCharges, String smsCharges, String dataCharges, String roamingCharges) {
		super();
		this.planName = planName;
		this.monthlyRental = monthlyRental;
		this.freeInternet = freeInternet;
		this.freeCalls = freeCalls;
		this.freeSms = freeSms;
		this.callCharges = callCharges;
		this.smsCharges = smsCharges;
		this.dataCharges = dataCharges;
		this.roamingCharges = roamingCharges;
	}
	@Override
	public String toString() {
		return "Telecom [PlanName=" + getPlanName() + ", MonthlyRental=" + getMonthlyRental()
				+ ", FreeInternet=" + getFreeInternet() + ", FreeCalls=" + getFreeCalls() + ", FreeSms="
				+ getFreeSms() + ", CallCharges=" + getCallCharges() + ", SmsCharges=" + getSmsCharges()
				+ ", DataCharges=" + getDataCharges() + ", RoamingCharges=" + getRoamingCharges() + "]";
	}
}

